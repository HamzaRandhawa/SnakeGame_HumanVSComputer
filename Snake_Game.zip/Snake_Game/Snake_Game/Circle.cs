﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snake_Game
{
    class Circle
    {
        public int x { set; get; }
        public int y { set; get; }

        public Circle()
        {
            x = 0;
            y = 0;
        }
        //public Circle(int X , int Y)
        //{
        //    x = X;
        //    y = Y;
        //}
    }
}
