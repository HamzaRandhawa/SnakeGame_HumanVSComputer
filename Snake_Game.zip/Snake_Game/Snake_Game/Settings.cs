﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Snake_Game
{
    public enum Direction
    {
        Right, Left, Up, Down
    }

    class Settings
    {
        public static int Width { set; get; }
        public static int Height { set; get; }
        public static int Speed { set; get; }
        public static int Score_1 { set; get; }
        public static int Score_2 { set; get; }
        public static int Points { set; get; }

        public static bool Is_Game_Over { set; get; }
        public static Direction direction_1 { set; get; }
        public static Direction direction_2 { set; get; }

        public static int Target { set; get; }

        public Settings()
        {
            Target = 100;

            Width = 17;
            Height = 17;
            Speed = 12;
            Score_1 = 0;
            Score_2 = 0;
            Points = 10;
            Is_Game_Over = false;

            direction_1 = Direction.Down;
            direction_2 = Direction.Down;
        }

    }
}
